#!/usr/bin/env python3
"""Compare concrete installed/candidate Core7 contracts and actual native outcomes."""
import hashlib
import json
import os
import pathlib
import queue
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.request

OUT = pathlib.Path(__file__).resolve().parent
BINS = {
    "stable": pathlib.Path("/opt/homebrew/Cellar/rightclick/0.2.2/bin/rightclick"),
    "candidate": pathlib.Path("/private/tmp/rightclick-pr-delivery-queue-20261007/.build/release/rightclick"),
}
TOOLS = {"context_runtime", "context_providers", "context_inspect", "context_actions",
         "context_explain", "context_run", "context_run_status"}
FULL = "service:com.apple.ChineseTextConverterService:convertTextToFullWidth"
catalogues = {label: json.loads((OUT / (label + "-text.stdout")).read_text())["actions"]
              for label in BINS}
candidate_ids = {row["id"] for row in catalogues["candidate"]}
gate = next(row["id"] for row in catalogues["stable"]
            if row["id"] in candidate_ids and row["requiresConfirmation"])
records = {}

def exercise(binary, label, transport, request):
    directory = OUT / (label + "-" + transport)
    directory.mkdir(exist_ok=True)
    sequence = 0
    def rpc(method, params):
        nonlocal sequence
        sequence += 1
        reply = request({"jsonrpc": "2.0", "id": sequence, "method": method, "params": params})
        (directory / (str(sequence) + "-" + method.replace("/", "-") + ".json")).write_text(
            json.dumps(reply, ensure_ascii=False, indent=2) + "\n")
        assert "error" not in reply, reply
        return reply["result"]
    def call(name, arguments):
        value = rpc("tools/call", {"name": name, "arguments": arguments})
        assert not value.get("isError"), value
        return json.loads(value["content"][0]["text"])
    init = rpc("initialize", {"protocolVersion": "2025-03-26", "capabilities": {},
        "clientInfo": {"name": "rightclick-version-parity", "version": "1"}})
    tools = rpc("tools/list", {})["tools"]
    assert {tool["name"] for tool in tools} == TOOLS
    runtime = call("context_runtime", {})
    assert runtime["executableSHA256"] == hashlib.sha256(binary.read_bytes()).hexdigest()
    assert runtime["transport"] == transport and os.path.samefile(runtime["executableRealPath"], binary)
    assert init["serverInfo"]["version"] == runtime["version"]
    providers = call("context_providers", {})
    inspected = call("context_inspect", {"item": "RightClick"})
    assert inspected["text"] == "RightClick" and inspected["typeIdentifier"] == "public.plain-text"
    actions = call("context_actions", {"item": "RightClick"})
    explained = call("context_explain", {"item": "RightClick", "actionId": FULL})
    assert explained["id"] == FULL
    gated = call("context_run", {"item": "RightClick", "actionId": gate})
    assert gated["state"] == "awaiting_user" and "CONFIRMATION_REQUIRED" in gated["message"]
    result = call("context_run", {"item": "RightClick", "actionId": FULL,
        "confirmed": True, "expectedOutput": "ＲｉｇｈｔＣｌｉｃｋ"})
    assert result["state"] == "succeeded" and result["output"] == "ＲｉｇｈｔＣｌｉｃｋ"
    assert result["evidence"]["outcomeVerified"] and result["evidence"]["type"] == "returned_text_postcondition"
    status = call("context_run_status", {"executionId": result["executionId"]})
    assert status["state"] == result["state"] and status["output"] == result["output"]
    assert status["evidence"] == result["evidence"]
    summary = {"runtime": runtime, "tools": tools, "providers": providers, "inspect": inspected,
        "actions": actions, "explain": explained, "confirmation": gated, "verified": result, "status": status}
    (directory / "results.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    records[(label, transport)] = summary
    print(label, transport, "GREEN: Core7 schemas, attestation, actual discovered confirmation gate, exact native output and retained status", flush=True)

for label, binary in BINS.items():
    with (OUT / (label + "-stdio.stderr")).open("w") as errors:
        process = subprocess.Popen([str(binary), "mcp"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=errors, text=True, bufsize=1)
        replies = queue.Queue()
        def reader():
            with (OUT / (label + "-stdio.raw")).open("w") as raw:
                for line in process.stdout:
                    raw.write(line); raw.flush()
                    try:
                        replies.put(json.loads(line))
                    except ValueError:
                        with (OUT / (label + "-stdio-nonjson.txt")).open("a") as bad:
                            bad.write(line)
                replies.put(None)
        threading.Thread(target=reader, daemon=True).start()
        def stdio(request):
            process.stdin.write(json.dumps(request) + "\n")
            process.stdin.flush()
            while True:
                reply = replies.get(timeout=40)
                assert reply is not None, "stdio ended"
                if reply.get("id") == request["id"]:
                    return reply
        try:
            exercise(binary, label, "stdio", stdio)
        finally:
            process.terminate()
            process.wait(timeout=10)
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]
    token = os.urandom(32).hex()
    environment = dict(os.environ, RIGHTCLICK_MCP_TOKEN=token)
    with (OUT / (label + "-http.stderr")).open("w") as errors:
        process = subprocess.Popen([str(binary), "mcp", "--http", "--port", str(port)],
            stdout=subprocess.DEVNULL, stderr=errors, env=environment)
        try:
            for _ in range(100):
                try:
                    with socket.create_connection(("127.0.0.1", port), timeout=.1):
                        break
                except OSError:
                    time.sleep(.1)
            else:
                raise RuntimeError("HTTP listener did not start")
            def http(request, authenticated=True):
                headers = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream"}
                if authenticated:
                    headers["Authorization"] = "Bearer " + token
                query = urllib.request.Request("http://127.0.0.1:" + str(port) + "/mcp",
                    json.dumps(request).encode(), headers)
                with urllib.request.urlopen(query, timeout=40) as response:
                    raw = response.read().decode()
                    if response.headers.get("Content-Type", "").startswith("text/event-stream"):
                        return next(json.loads(line[6:]) for line in raw.splitlines() if line.startswith("data: "))
                    return json.loads(raw)
            try:
                http({"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}}, False)
                raise AssertionError("Unauthenticated HTTP accepted")
            except urllib.error.HTTPError as error:
                assert error.code == 401
            exercise(binary, label, "http", http)
        finally:
            process.terminate()
            process.wait(timeout=10)

schema_differences = {}
for transport in ["stdio", "http"]:
    old = {row["name"]: row["inputSchema"] for row in records[("stable", transport)]["tools"]}
    new = {row["name"]: row["inputSchema"] for row in records[("candidate", transport)]["tools"]}
    changes = {}
    for name in TOOLS:
        a, b = old[name], new[name]
        assert set(b.get("required", [])) <= set(a.get("required", [])), name
        assert a.get("type") == b.get("type"), name
        for prop, schema in a.get("properties", {}).items():
            assert prop in b.get("properties", {}), (name, prop)
            # Description changes do not narrow accepted JSON values.
            old_shape = {k: v for k, v in schema.items() if k != "description"}
            new_shape = {k: v for k, v in b["properties"][prop].items() if k != "description"}
            assert old_shape == new_shape, (name, prop, old_shape, new_shape)
        additions = set(b.get("properties", {})) - set(a.get("properties", {}))
        changes[name] = {"addedOptionalProperties": sorted(additions), "legacyPropertiesPreserved": True}
    schema_differences[transport] = changes
(OUT / "mcp-parity-summary.json").write_text(json.dumps({"result": "GREEN", "confirmationAction": gate,
    "schemaCompatibility": schema_differences, "scope": "Same-host installed 0.2.2 and unpublished local 0.2.3. Native text and confirmation; configured external transports tested separately."}, indent=2) + "\n")
print("GREEN: all seven legacy input schemas preserved; optional additions recorded", flush=True)
